package com.example.springrmiserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRmiServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
